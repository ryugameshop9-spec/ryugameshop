global.feenya = 150//atur fee nya misal harga asli 1.480 + fee 200 jadi harganya 1.680
global.apikey = "KhafaTopUp_stscj7bmmvm5s9n0" //isi apikey dari https://khafatopup.my.id minta verifikasi h2h ke admin nya



